<?php
/**
 * Created by PhpStorm.
 * User: Niruhan
 * Date: 12/11/2016
 * Time: 11:05 PM
 */

require "dbconnect.php";
?>


<form action="dbquery.php" method="get">
    Select permission level:
    <select name="permission">
        <option value="admin">Admin</option>
        <option value="user">User</option>
    </select><br><br>
    <input type="submit" value="Submit">
</form>

<?php

if (isset($_GET['permission'])&&!empty($_GET['permission'])) {
    $permission = strtolower($_GET['permission']);

    if ($permission=='admin'||$permission=='user'||1==1) {
        $query = "SELECT username, password FROM users WHERE permission='$permission' ORDER BY id DESC";

        if ($query_run = mysqli_query($con, $query)) {
            echo 'Query success!<br>';
            if ($query_run->num_rows==NULL) {
                echo 'no results found';
            } else {
                while ($query_row = mysqli_fetch_assoc($query_run)) {
                    $username = $query_row['username'];
                    $password = $query_row['password'];
                    echo $username . " " . $password . '<br>';
                }
            }
        } else {
            echo "Query failed!";
            die(mysqli_error($con));
        }
    } else {
        echo "Must be admin or user!";
    }
}
?>