<?php
/**
 * Created by PhpStorm.
 * User: Niruhan
 * Date: 12/11/2016
 * Time: 9:32 PM
 */

error_reporting(E_ALL);

$conn_error = "Could not connect";

$mysql_host = "127.0.0.1";
$mysql_user = "root";
$mysql_pass = "";
$mysql_db = "mydb";

if(!mysqli_select_db(mysqli_connect($mysql_host, $mysql_user, $mysql_pass), $mysql_db)) {
    die($conn_error);
} else {
    echo "Connected!";
}

?>