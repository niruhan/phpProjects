<?php
/**
 * Created by PhpStorm.
 * User: Niruhan
 * Date: 12/11/2016
 * Time: 11:05 PM
 */

require "dbconnect.php";


$query = "SELECT username, password FROM users WHERE permission='admin' ORDER BY id DESC";

if ($query_run=mysqli_query($con, $query)) {
    echo 'Query success!<br>';
    while ($query_row = mysqli_fetch_assoc($query_run)) {
        $username = $query_row['username'];
        $password = $query_row['password'];
        echo $username." ".$password.'<br>';
    }
} else {
    echo "Query failed!";
    die(mysqli_error($con));
}

?>